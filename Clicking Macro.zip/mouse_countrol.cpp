#include <cstdint>
#include <cstring>

#include <linux/uinput.h> // mouse stuff
#include <unistd.h>
#include <fcntl.h>

#include "headers/set_events.h"

const uint64_t MAX_RES_X = 2560 - 1;
const uint64_t MAX_RES_Y = 1440 - 1;

const uint64_t delay = 150'000; // in microseconds
                                // 1 microsecond = 0.000'001 seconds

int open_virtual_mouse() {
    int communicator = open("/dev/uinput", O_WRONLY | O_NONBLOCK);
    set_rel_events(communicator);
    set_abs_events(communicator);
    set_button_events(communicator);
    return communicator;
}

void setup_virtual_mouse(int communicator) {
    uinput_setup setup = {};
    setup.id.bustype = BUS_USB;
    setup.id.vendor  = 0x1234;
    setup.id.product = 0x5678;
    strcpy(setup.name, "Virtual C++ Mouse");

    uinput_abs_setup abs_setup = {};
    abs_setup.code = ABS_X;
    abs_setup.absinfo.maximum = MAX_RES_X;
    ioctl(communicator, UI_ABS_SETUP, &abs_setup);

    abs_setup.code = ABS_Y;
    abs_setup.absinfo.maximum = MAX_RES_Y;
    ioctl(communicator, UI_ABS_SETUP, &abs_setup);

    ioctl(communicator, UI_DEV_SETUP, &setup);
    ioctl(communicator, UI_DEV_CREATE);

    usleep(100'000); // let OS register the device
}

void close_virtual_mouse(int communicator) {
    ioctl(communicator, UI_DEV_DESTROY);
    close(communicator);
}

void move_mouse_to(int communicator, int x, int y) {
    input_event move_pos[3]{};

    move_pos[0].type = EV_ABS;
    move_pos[0].code = ABS_X;
    move_pos[0].value = x;

    move_pos[1].type = EV_ABS;
    move_pos[1].code = ABS_Y;
    move_pos[1].value = y;

    move_pos[2].type = EV_SYN;
    move_pos[2].code = SYN_REPORT;
    move_pos[2].value = 0;

    write(communicator, move_pos, sizeof(move_pos));
    usleep(delay); // give OS time to process
}

void update_mouse_click(int communicator, int event_type, int click_type, int event_data) {
    input_event mouse_click = {};
    mouse_click.type = event_type;
    mouse_click.code = click_type;
    mouse_click.value = event_data;
    write(communicator, &mouse_click, sizeof(mouse_click));
}

void left_click(int communicator) {
    update_mouse_click(communicator, EV_KEY, BTN_LEFT, 1);  // press
    update_mouse_click(communicator, EV_SYN, SYN_REPORT, 0);

    update_mouse_click(communicator, EV_KEY, BTN_LEFT, 0);  // release
    update_mouse_click(communicator, EV_SYN, SYN_REPORT, 0);
}

void right_click(int communicator) {
    update_mouse_click(communicator, EV_KEY, BTN_RIGHT, 1); // press
    update_mouse_click(communicator, EV_SYN, SYN_REPORT, 0);

    update_mouse_click(communicator, EV_KEY, BTN_RIGHT, 0); // release
    update_mouse_click(communicator, EV_SYN, SYN_REPORT, 0);
}