#include <linux/uinput.h>

void set_rel_events(int communicator) {
    ioctl(communicator, UI_SET_EVBIT, EV_REL);
    ioctl(communicator, UI_SET_RELBIT, REL_X);
    ioctl(communicator, UI_SET_RELBIT, REL_Y);
}

void set_abs_events(int communicator) {
    ioctl(communicator, UI_SET_EVBIT, EV_ABS);
    ioctl(communicator, UI_SET_ABSBIT, ABS_X);
    ioctl(communicator, UI_SET_ABSBIT, ABS_Y);
}

void set_button_events(int communicator) {
    ioctl(communicator, UI_SET_EVBIT, EV_KEY);
    ioctl(communicator, UI_SET_KEYBIT, BTN_LEFT);
    ioctl(communicator, UI_SET_KEYBIT, BTN_RIGHT); // enable right click
}