#ifndef _SET_EVENTS_H
#define _SET_EVENTS_H

void set_rel_events(int communicator);
void set_abs_events(int communicator);
void set_button_events(int communicator);
void update_mouse_click(int communicator, int event_type, int click_type, int event_data);

#endif