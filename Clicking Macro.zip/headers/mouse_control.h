#ifndef _MOUSE_CONTROL_H
#define _MOUSE_CONTROL_H

int open_virtual_mouse();
void setup_virtual_mouse(int communicator);
void close_virtual_mouse(int communicator);
void move_mouse_to(int communicator, int x, int y);
void left_click(int communicator);
void right_click(int communicator);

#endif