#include <iostream>

#include <chrono> // sleep() & usleep()
#include <thread>

#include "headers/mouse_control.h"

using namespace std;

int main() {
    uint64_t communicator = open_virtual_mouse();
    setup_virtual_mouse(communicator);
    move_mouse_to(communicator, 100, 100);

    right_click(communicator);
    close_virtual_mouse(communicator);

    cout << "Hello, World!\n";
    return 0;
}